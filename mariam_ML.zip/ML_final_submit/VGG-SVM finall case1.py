#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import os
import random
from tqdm import tqdm
import xgboost as xgb
import tensorflow as tf
import cv2
from keras_applications.resnet import ResNet50
# from keras.applications.resnet18 import ResNet18
from keras.models import Model
from keras.preprocessing import image
from keras.applications.resnet import preprocess_input, decode_predictions
from keras.layers import Flatten, Input
from tensorflow.keras.utils import img_to_array, load_img
import scipy
from sklearn.metrics import fbeta_score
from keras.applications.vgg16 import VGG16
from keras.applications.vgg16 import preprocess_input
import numpy as np
from sklearn import preprocessing
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import train_test_split
import xgboost
import glob


# In[ ]:





# In[2]:


files = []
categories = []

for directory_path in glob.glob('E:/downloads/project_dataset/Alzheimer_s Dataset/train/*'):

    label=directory_path.split('\\')[-1]
    
    for img_path in glob.glob(os.path.join(directory_path,'*.jpg')):
        files.append(img_path)
        categories.append(label)

df = pd.DataFrame({
 'Filename': files,
 'Category': categories
})

df


# In[3]:


df['Category'].value_counts()


# In[4]:


le = preprocessing.LabelEncoder()
le.fit(df['Category'])
le_name_mapping = dict(zip(le.classes_, le.transform(le.classes_)))
print(le_name_mapping)


# In[5]:


y = le.transform(df['Category'])


# In[6]:


base_model = VGG16(weights='imagenet', include_top=False)
inputs = Input(shape=(48,48,3),name = 'image_input')
x = base_model(inputs)
x = Flatten()(x)
model = Model(inputs=inputs, outputs=x)


# In[7]:


# # case 2
# from tensorflow.keras import layers, models
# model=models.Sequential([
#     base_model,
#     layers.Flatten(),
#     layers.Dense(50, activation='relu'),
#     layers.Dense(20, activation='relu'),
#     layers.Dense(4, activation='softmax')
# ])


# In[8]:


import time
start = time.time()

x_train = []
y_train = []

for f in tqdm(df.Filename[:]):
    img_path = f
    img = load_img(img_path, target_size=(48, 48))
    x = img_to_array(img)
    x = np.expand_dims(x, axis=0)
    x = preprocess_input(x)

    features = model.predict(x)
    features_reduce =  features.squeeze()
    x_train.append(features_reduce)


# In[13]:


x_train.shape


# In[9]:


scaler = MinMaxScaler()
scaler.fit(x_train)
x_train = scaler.transform(x_train)


# In[10]:


x_train, x_valid, y_train, y_valid = train_test_split(x_train, y, test_size = 0.5, stratify = y, random_state = 8)


# In[15]:


#Import svm model
from sklearn import svm

#Create a svm Classifier
clf = svm.SVC(kernel='linear') # Linear Kernel

#Train the model using the training sets
clf.fit(x_train, y_train)

#Predict the response for test dataset
y_pred=clf.predict(x_valid)


# In[17]:


from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
print(accuracy_score(y_pred, y_valid))
print(f1_score(y_pred, y_valid, average="macro"))


# In[16]:


files = []
categories = []

for directory_path in glob.glob('E:/downloads/project_dataset/Alzheimer_s Dataset/test/*'):

    label=directory_path.split('\\')[-1]
    
    for img_path in glob.glob(os.path.join(directory_path,'*.jpg')):
        files.append(img_path)
        categories.append(label)

df = pd.DataFrame({
 'Filename': files,
 'Category': categories
})

df


# In[18]:


df['Category'].value_counts()


# In[19]:


le = preprocessing.LabelEncoder()
le.fit(df['Category'])
le_name_mapping = dict(zip(le.classes_, le.transform(le.classes_)))
print(le_name_mapping)


# In[20]:


y = le.transform(df['Category'])


# In[21]:


start = time.time()

x_test = []
y_test = y

for f in tqdm(df.Filename[:]):
    img_path = f
    img = load_img(img_path, target_size=(48, 48))
    x = img_to_array(img)
    x = np.expand_dims(x, axis=0)
    x = preprocess_input(x)

    features = model.predict(x)
    features_reduce =  features.squeeze()
    x_test.append(features_reduce)


# In[22]:


scaler = MinMaxScaler()
scaler.fit(x_train)
x_test = scaler.transform(x_test)


# In[23]:


y_pred = clf.predict(x_test)


# In[24]:


print(accuracy_score(y_pred, y_test))

print(f1_score(y_pred, y_test, average="macro"))


# In[27]:


from sklearn.metrics import classification_report
print(classification_report(y_test, y_pred))


# In[ ]:


# case 2
add more layers


# In[ ]:





# In[ ]:




